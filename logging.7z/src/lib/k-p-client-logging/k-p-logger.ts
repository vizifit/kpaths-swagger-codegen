import {ILogger} from "./interfaces/i-logger";
import {LogLevel} from "./enums/log-level.enum";
import {IKPLog} from "./interfaces/i-k-p-log";

export class KPLogger implements ILogger{

  constructor(private _log:IKPLog, public category:string, private _callback:Function){

  }

  log(level:LogLevel, message:string, ... rest):void {
    this._callback.apply(this._log,[level,this.category,message].concat(rest));
  }
  debug(message:string, ... rest):void{
    this.log.apply(this,[LogLevel.DEBUG,message].concat(rest));
  }
  error(message:string, ... rest):void{
    this.log.apply(this,[LogLevel.ERROR,message].concat(rest));
  }
  fatal(message:string, ... rest):void{
    this.log.apply(this,[LogLevel.FATAL,message].concat(rest));
  }
  info(message:string, ... rest):void{
    this.log.apply(this,[LogLevel.INFO,message].concat(rest));
  }
  warn(message:string, ... rest):void{
    this.log.apply(this,[LogLevel.WARN,message].concat(rest));
  }

}
