import {ILoggingTarget} from "../interfaces/i-logging-target";
import {ILogger} from "../interfaces/i-logger";
import {LogLevel} from "../enums/log-level.enum";
import {KPLogTargetUtils} from "../utils/k-p-log-target-utils";
import {KPLogTargetPreferences} from "../preferences/k-p-log-target-preferences";

export class ConsoleTarget implements ILoggingTarget{

  preferences:KPLogTargetPreferences;
  filters:Array<string>;
  level:number;
  fieldSeparator:string = '|';
  includeDate:boolean = true;
  includeTime:boolean = true;
  includeLevel:boolean = true;
  includeCategory:boolean = true;
  additionalLogInfoString:string;

  addLogger(logger:ILogger):void
  {

  }
  removeLogger(logger:ILogger):void
  {

  }

  processLogMessage(time:Date, level:LogLevel,category:string,message:string, ... rest): void
  {
    let delimiter:string = this.fieldSeparator;
    var fields:Array<string> = [];
    var date:Date;
    if (this.preferences.omitLogInformation)
    {
      console.log(message);
      return;
    }
    if(this.includeDate || this.includeTime)
    {
      date = new Date();
    }
    if (this.includeDate)
    {
      fields.push(KPLogTargetUtils.logDate(date,this.preferences));
    }
    if (this.includeTime)
    {
      fields.push(KPLogTargetUtils.logTime(date,this.preferences));
    }
    if (this.includeLevel)
    {
      fields.push(KPLogTargetUtils.logLevel(level,this.preferences));
    }
    if (this.includeCategory)
    {
      fields.push(KPLogTargetUtils.logCategory(category,this.preferences));
    }
    if(this.preferences.prependMessageWithDelimiter)
    {
      delimiter = this.preferences.messageDelimiter;
    }
    if(this.additionalLogInfoString)
    {
      fields.push(this.additionalLogInfoString);
    }
      console.log(fields.join(this.fieldSeparator)+delimiter+message);
  }
}
