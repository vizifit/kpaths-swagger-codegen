export enum LogLevel {
  ALL,
  DEBUG,
  INFO,
  WARN,
  ERROR,
  FATAL
}
