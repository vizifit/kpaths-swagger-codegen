import {IKPLog} from "./interfaces/i-k-p-log";
import {ILoggingTarget} from "./interfaces/i-logging-target";
import {ILogger} from "./interfaces/i-logger";
import {KPLogger} from "./k-p-logger";
import {LogLevel} from "./enums/log-level.enum";
import {ICategoryMapping} from "./interfaces/i-category-mapping";
import {KPLogTargetUtils} from "./utils/k-p-log-target-utils";

export class KPLogImpl implements IKPLog{
  private static _instance:IKPLog;
  private static _lock:Object = {};
  public static getInstance():IKPLog{
    if(!this._instance)
    {
      this._instance = new KPLogImpl(this._lock);
    }
    return this._instance;
  }

  private _targets:Array<ILoggingTarget>;
  private _loggers:Array<ILogger>;
  private _map:Object;
  constructor(lock:Object){
    if(lock !== KPLogImpl._lock)
    {
      throw new Error("Instantiation not allowed outside of KPLogImpl");
    }
    this.flush();
  }


  initialize(logTarget:ILoggingTarget):void{
      this.addTarget(logTarget);
  }
  getLogger(callingObject:any):ILogger{
    let category:string = callingObject.constructor.name;
    let mapping:ICategoryMapping = this._map[category];
    let result:ILogger;
    if(!mapping)
    {
      result = new KPLogger(this,category,function (level:LogLevel,category:string,message:string, ... rest) {
            this.processLogMessage.apply(this,[level, category, message].concat(rest));
      });
      this._loggers.push(result);
      this.mapLoggerToTargets(result);
    } else {
      result = mapping.logger;
    }
    return result;
  }
  registerFilters(target:ILoggingTarget, qualifiedFilters:Array<string>):void{

  }
  getFilter(values:Array<string>):Array<string>{
    return null;
  }
  flush():void{
    if(this._map) {
      // TODO: cleanup any references
    }
    if(this._targets) {
      // TODO: cleanup any references
    }
    if(!this._loggers)
    {
      this._loggers = [];
    }
    this._map = {};
    this._targets = [];
  }
  addTarget(target:ILoggingTarget):void{
    if(this._targets.indexOf(target) < 0){
      this._targets.push(target);
    }
    this.mapTargetToLoggers(target);
  }
  removeTarget(target:ILoggingTarget):void{
    let i:number = this._targets.indexOf(target);
    if(i >= 0){
      this._targets.splice(i,1);
    }
  }

  processLogMessage(level:LogLevel,category:string,message:string, ... rest): void
  {
    let mapping:ICategoryMapping = this._map[category];
    let time:Date = new Date();
    for(let target of mapping.targets)
    {
      if(target.level <= level)
      {
        target.processLogMessage.apply(target,[time,level,category,message].concat(rest));
      }
    }
  }

  private mapLoggerToTargets(logger:ILogger):void {
    let mapping:ICategoryMapping = this.getLoggerMapping(logger);
    let targets:Array<ILoggingTarget> = mapping.targets;
    for (let target of this._targets){
        if(KPLogTargetUtils.filterCategory(target.filters,logger.category) && !(targets.indexOf(target) >= 0)) {
          targets.push(target);
        }
    }
  }

  private mapTargetToLoggers(target:ILoggingTarget):void{
    for(let logger of this._loggers)
    {
      let mapping:ICategoryMapping = this.getLoggerMapping(logger);
      if(KPLogTargetUtils.filterCategory(target.filters,logger.category) && !(mapping.targets.indexOf(target) >= 0))
      {
        mapping.targets.push(target);
      }
    }
  }

  private getLoggerMapping(logger:ILogger):ICategoryMapping
  {
    let mapping:ICategoryMapping = this._map[logger.category];
    if(!mapping) {
      mapping = {logger:logger, targets:[]};
      this._map[logger.category] = mapping;
    }
    return mapping;
  }

}
