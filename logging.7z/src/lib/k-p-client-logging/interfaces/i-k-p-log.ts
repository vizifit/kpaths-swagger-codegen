import {ILoggingTarget} from "./i-logging-target";
import {ILogger} from "./i-logger";

export interface IKPLog{

  getLogger(callingObject:any):ILogger;
  registerFilters(target:ILoggingTarget, qualifiedFilters:Array<string>):void;
  getFilter(values:Array<string>):Array<string>;
  flush():void;
  addTarget(target:ILoggingTarget):void;
  removeTarget(target:ILoggingTarget):void;
  initialize(logTarget:ILoggingTarget):void;
}
