import {LogLevel} from "../enums/log-level.enum";

export interface ILogger{
  category:string;
log(level:LogLevel, message:string, ... rest):void;
debug(message:string, ... rest):void;
error(message:string, ... rest):void;
fatal(message:string, ... rest):void;
info(message:string, ... rest):void;
warn(message:string, ... rest):void;
}
