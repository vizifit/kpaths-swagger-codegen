import {ILogger} from "./i-logger";
import {LogLevel} from "../enums/log-level.enum";
import {KPLogTargetPreferences} from "../preferences/k-p-log-target-preferences";

export interface ILoggingTarget {
  filters:Array<string>;
  level:number;
  preferences:KPLogTargetPreferences;
  addLogger(logger:ILogger):void;
  removeLogger(logger:ILogger):void;
  processLogMessage(time:Date, level:LogLevel,category:string,message:string, ... rest): void;
}
