import {ILogger} from "./i-logger";

export interface ILog {
  log:ILogger;
}
