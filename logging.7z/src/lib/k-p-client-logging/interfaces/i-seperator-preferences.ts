export interface ISeperatorPreferences {
  afterS?:string;
  afterM?:string;
  afterH?:string;
}
