import {ILoggingTarget} from "./i-logging-target";
import {ILogger} from "./i-logger";

export interface ICategoryMapping {
  targets:Array<ILoggingTarget>
  logger:ILogger;
}
