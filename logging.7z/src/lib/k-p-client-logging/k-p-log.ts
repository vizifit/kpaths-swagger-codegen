import {IKPLog} from "./interfaces/i-k-p-log";
import {KPLogImpl} from "./k-p-log-impl";

export class KPLog {

  private static _instance:IKPLog;
  private static _impl:any = KPLogImpl;

  public static set impl(value:any) {
    if(KPLog._impl)
    {
      KPLog._instance = null;
    }
    KPLog._impl = value;
    KPLog.instance();
  }

  public static instance():IKPLog{
    if(!KPLog._instance)
    {
      KPLog._instance = KPLog._impl.getInstance();
    }
    return KPLog._instance;
  }


}
