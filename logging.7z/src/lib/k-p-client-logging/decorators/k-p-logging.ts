import {ILogger} from "../interfaces/i-logger";
import {KPLog} from "../k-p-log";
import {ILog} from "../interfaces/i-log";
import {IKPLog} from "../interfaces/i-k-p-log";

export function KPLogging<T extends { new (...args: any[]): {} }>(constructor: T) {

  let o:any = constructor;
  // a utility function to generate instances of a class
     function construct(constructor, args) {
         var c : any = function () {
             return constructor.apply(this, args);
           }
         c.prototype = constructor.prototype;
         return new c();
       }

     // the new constructor behaviour
     let f : any = function (...args) {
          let i:ILog = construct(o, args);
          i.log = KPLog.instance().getLogger(i);
         return i;
       };

     // copy prototype so intanceof operator still works
     f.prototype = o.prototype;




    return f;
  }
