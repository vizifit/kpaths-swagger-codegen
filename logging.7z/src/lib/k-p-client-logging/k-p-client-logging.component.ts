import { Component, OnInit } from '@angular/core';
import {ILogger} from "./interfaces/i-logger";
import {KPLog} from "./k-p-log";
import {KPLogging} from "./decorators/k-p-logging";
import {ILog} from "./interfaces/i-log";



@Component({
  selector: 'cccs-client-log-client-logging',
  templateUrl: './client-logging.component.html',
  styleUrls: ['./client-logging.component.css']
})
@KPLogging
export class ClientLoggingComponent implements OnInit {
  log:ILogger;
  constructor() {

  }
  ngOnInit() {
   this.log.debug("testing");
   this.log.info("info");

  }

}
