import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ClientLoggingComponent } from './client-logging.component';
import {ConsoleTarget} from "./targets/console-target";
import {IKPLog} from "./interfaces/i-k-p-log";

@NgModule({
  imports: [
    CommonModule
  ],
  declarations: [ClientLoggingComponent],
  exports: [ClientLoggingComponent],
})
export class ClientLoggingModule { }
