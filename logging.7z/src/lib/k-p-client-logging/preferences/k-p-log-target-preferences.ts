export class KPLogTargetPreferences {
  public static getDefaultPreferences():KPLogTargetPreferences{
    if(!KPLogTargetPreferences._default){
      KPLogTargetPreferences._default = new KPLogTargetPreferences();
    }
    return KPLogTargetPreferences._default;
  }

  private static _default:KPLogTargetPreferences;

  constructor(){

  }

  omitLogInformation:boolean = false;

  /**
   * <p/>Boolean flag that determines if a string delimiter should be used in the Log output between the Log information and the Log message.<br/>
   * Set this variable to <code>true</code> to allow the delimiter to be displayed in the Log output.<br/>
   * Set this variable to <code>false</code> to omit the displaying of the delimiter in the Log output.
   *
   * @default true
   */
  prependMessageWithDelimiter:boolean = true;

  /**
   * <p/>Boolean flag that determines if the full class package is displayed as the category name in the Log output.<br/>
   * Set this variable to <code>true</code> to display just the Classname in the Log output.<br/>
   * Set this variable to <code>false</code> to display the full package path including the Classname in the Log output.<br/>
   * This variable is only respected if the includeCategory property is set to <code>true</code>.
   *
   * @default true
   * @see the public Boolean variable includeCategory
   */
  omitPackagePathFromCategory:boolean = true;

  /**
   * <p/>Boolean flag that determines if the log level string should be truncated to one character in the Log output.<br/>
   * Set this variable to <code>true</code> to display just a single letter for the log level.<br/>
   * Set this variable to <code>false</code> if you want the log level string to stay as a full word (i.e. [WARN] instead of [W]) in the Log.<br/>
   * This variable is only respected if the includeLevel property is set to <code>true</code>.
   *
   * @default true
   * @see the public Boolean variable includeLevel
   */
 truncateLevel:boolean = false;

  /**
   * <p/>Boolean flag that determines the formatting of the display of hours in the Log output.<br/>
   * Set this variable to <code>true</code> to omit the display of the hours in the Log output.<br/>
   * Set this variable to <code>false</code> if you want the hours to be displayed in the Log output.<br/>
   * This feature is usually used to save horizontal space in the console.
   *
   * @default true
   * @see the public Boolean variable omitHours
   */
  omitHours:boolean = true;

  /**
   * <p/>Boolean flag that determines the formatting of the display of minutes in the Log output.<br/>
   * Set this variable to <code>true</code> to omit the display of the minutes in the Log output.<br/>
   * Set this variable to <code>false</code> if you want the minutes to appear in the Log output.<br/>
   * This variable is only respected if the omitHours variable is set to <code>true</code> and the
   * includeTime variable is set to <code>true</code>.<br/>
   * This feature is usually used to save horizontal space in the console.
   *
   * @default true
   * @see the public Boolean variable omitHours
   * @see the public Boolean variable includeTime
   */
  omitMinutes:boolean = true;

  /**
   * <p/>Boolean flag that determines the formatting of the display of seconds in the Log output.<br/>
   * Set this variable to <code>true</code> to omit the display of the seconds in the Log output.<br/>
   * Set this variable to <code>false</code> to display of the seconds in the Log output.<br/>
   * This variable is usually set to <code>true</code> to save horizontal space in the console.<br/>
   *
   * @default true
   * @see the public Boolean variable omitHours
   * @see the public Boolean variable omitMinutes
   */
  omitSeconds:boolean = true;

  /**
   * <p/>Boolean flag that determines the formatting of the display of milliseconds in the Log output.<br/>
   * Set this variable to <code>true</code> to omit the display of the milliseconds in the Log output.<br/>
   * Set this variable to <code>false</code> to display of the milliseconds in the Log output.<br/>
   * This variable is usually set to <code>true</code> to save horizontal space in the console.<br/>
   *
   * @default true
   * @see the public Boolean variable omitHours
   * @see the public Boolean variable omitMinutes
   * @see the public Boolean variable omitSeconds
   */
  omitMilliseconds:boolean = true;

  /**
   * <p/>String to append to the end of the Log message.<br/>Use this property to
   * make a clearer seperation between the Log Information and the Log Meessage in the Log Event.
   *
   * @default "msg: "
   */
  messageDelimiter:string = 'msg: ';

  /**
   * <p/>String to append to the end of the Timestamp in the Log if the inherited
   * public property includeTime is set to <code>true</code>.
   *
   * @default "ms"
   */
  millisecondLabel:string = 'ms';

  clone():KPLogTargetPreferences{
    let newClone:KPLogTargetPreferences = new KPLogTargetPreferences();
    newClone.messageDelimiter = this.messageDelimiter;
    newClone.millisecondLabel = this.millisecondLabel;
    newClone.omitHours = this.omitHours;
    newClone.omitLogInformation = this.omitLogInformation;
    newClone.omitMilliseconds = this.omitMilliseconds;
    newClone.omitMinutes = this.omitMinutes;
    newClone.omitPackagePathFromCategory = this.omitPackagePathFromCategory;
    newClone.omitSeconds = this.omitSeconds;
    newClone.prependMessageWithDelimiter = this.prependMessageWithDelimiter;
    newClone.truncateLevel = this.truncateLevel;
    return newClone;
  }
}
