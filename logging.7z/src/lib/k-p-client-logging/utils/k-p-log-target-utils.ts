import {KPLogTargetPreferences} from "../preferences/k-p-log-target-preferences";
import {ISeperatorPreferences} from "../interfaces/i-seperator-preferences";
import {LogLevel} from "../enums/log-level.enum";

export class KPLogTargetUtils {
  // These dictionaries are for caching things that are commonly displayed in line formatted output.
  // It is faster to access items in a dicitonary than to re-create them over and over.
  private static LOG_TIME_SEPERATORS:Object = {};
  private static LOG_LEVEL_STRINGS:Object = {};
  private static LOG_LEVEL_TRUNCATED_STRINGS:Object = {};
  private static LOG_PADDED_NUMBERS:Object = {};
  private static LOG_PADDED_MILL_NUMBERS:Object = {};

  constructor()
  {
    throw new Error("KPLogTargetUtils is not instantiable.");
  }

  public static logDate(d:Date, preferences:KPLogTargetPreferences):string
  {
    return KPLogTargetUtils.padTime(d.getMonth() + 1) + '/' + KPLogTargetUtils.padTime(d.getDate()) + '/' + d.getFullYear();
  }

  public static logTime(d:Date, preferences:KPLogTargetPreferences):string{
    let h:String = '';
    let m:String = '';
    let s:String = '';
    let ms:String = '';


    let seps:ISeperatorPreferences = KPLogTargetUtils.getLogTimeSeparators(preferences);

    if(!preferences.omitHours){
      h = KPLogTargetUtils.padTime(d.getHours());
    }
    if(!preferences.omitMinutes){
      m = KPLogTargetUtils.padTime(d.getMinutes());
    }
    if(!preferences.omitSeconds){
      s = KPLogTargetUtils.padTime(d.getSeconds());
    }
    if(!preferences.omitMilliseconds){
      ms = KPLogTargetUtils.padTime(d.getMilliseconds(), true) + preferences.millisecondLabel;
    }
    let time:string = h + seps.afterH + m + seps.afterM + s + seps.afterS + ms;
    return time;
  }

  private static getLogTimeSeparators( preferences:KPLogTargetPreferences):ISeperatorPreferences{
    let key:string = preferences.omitHours.toString() + preferences.omitMilliseconds.toString() + preferences.omitSeconds.toString() + preferences.omitMinutes.toString();
    let separators:ISeperatorPreferences = KPLogTargetUtils.LOG_TIME_SEPERATORS[key];
    if(separators)
    {
      return separators;
    }
    separators = {afterS:'.', afterM:':', afterH:':'};
    KPLogTargetUtils.LOG_TIME_SEPERATORS[key] = separators;
    if(preferences.omitMilliseconds || preferences.omitSeconds){
      separators.afterS = '';
    }
    if(preferences.omitMinutes || (preferences.omitMilliseconds && preferences.omitSeconds)){
      separators.afterM = '';
    }
    if(preferences.omitHours || (preferences.omitMilliseconds && preferences.omitSeconds && preferences.omitMinutes))
    {
      separators.afterH = '';
    }
    return separators;
  }

  public static logLevel(level:LogLevel,preferences:KPLogTargetPreferences):string
  {
    let levelLabel:string;
    let dictionary:Object;

    if (preferences.truncateLevel)
    {
      dictionary = KPLogTargetUtils.LOG_LEVEL_TRUNCATED_STRINGS;
    }
    else
    {
      dictionary = KPLogTargetUtils.LOG_LEVEL_STRINGS;
    }
    levelLabel = dictionary[level];
    if(levelLabel)
    {
      return levelLabel;
    }

    levelLabel = KPLogTargetUtils.getLevelString(level);
    if (preferences.truncateLevel)
    {
      levelLabel = levelLabel.substr(0, 1);
    }
    levelLabel = '[' + levelLabel + ']';
    dictionary[level] = levelLabel;
    return levelLabel;
  }

  public static logCategory(category:string, preferences:KPLogTargetPreferences):string
  {
    if (preferences.omitPackagePathFromCategory)
    {
      return KPLogTargetUtils.getClassNameFromCategoryString(category);
    }
    else
    {
      return category;
    }
  }

  public static getLevelString(level:LogLevel):string
  {
    return LogLevel[level];
  }

  /**
   * This method extracts the classname string from a category string
   *
   * @ return
   */
  public static getClassNameFromCategoryString(categoryString:string):string
  {
    let i:number = categoryString.lastIndexOf('.');
    if(i>-1)
    {
      return categoryString.substr(i+1);
    }
    return categoryString;
  }

  /**
   * This method formats a number into a human readable timestamp
   *
   * @return
   */
  public static padTime(num:number, millis:boolean = false):string
  {
    let padded:string;
    let dictionary:Object;
    if(millis)
    {
      dictionary = KPLogTargetUtils.LOG_PADDED_MILL_NUMBERS;
    }
    else
    {
      dictionary = KPLogTargetUtils.LOG_PADDED_NUMBERS;
    }
    padded = dictionary[num];
    if(padded)
    {
      return padded;
    }
    if(num < 10){
      padded = ( millis ? "00" : "0") + num.toString();
    } else if (millis && num < 100) {
      padded = "0" + num.toString();
    } else {
      padded = num.toString();
    }
    dictionary[num] = padded;
    return padded;
  }

  public static filterCategory(filters:Array<string>,category:string):boolean
  {
    let result:boolean = !filters || !filters.length;
    for(let filter of filters) {
      let w: number = filter.indexOf('*');
      if (w > 0) {
        result = filter.substring(0, w - 1) === category.substring(0, w - 1);
      } else if (w == 0) {
        result = true;
      } else {
        result = filter === category;
      }
    }
    return result;
  }
}
