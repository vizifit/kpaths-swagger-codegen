export * from './bookingController.service';
import { BookingControllerService } from './bookingController.service';
export const APIS = [BookingControllerService];
